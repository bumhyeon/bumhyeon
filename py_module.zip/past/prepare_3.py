from langchain.document_loaders import PyMuPDFLoader
from langchain.vectorstores import Chroma 
from langchain.text_splitter import SpacyTextSplitter
from langchain_openai import OpenAIEmbeddings

# PDF 파일 로드
loader = PyMuPDFLoader(r'C:\Users\bumi\Desktop\vscoder\03_retrieval\sample.pdf')
documents = loader.load()

# 텍스트 분할기 설정
text_splitter = SpacyTextSplitter(
    chunk_size=300,
    pipeline="ko_core_news_sm"
)

splitted_documents = text_splitter.split_documents(documents)

# OpenAI 임베딩 설정
embeddings = OpenAIEmbeddings(
    model="text-embedding-ada-002",
    openai_api_key="sk-proj-PKrHrTkG6coWLfyNKXglT3BlbkFJrGLttSNNW8kiqL8ZUqsS"
)


# Chroma 데이터베이스 생성 및 문서 추가
database = Chroma(
    persist_directory='./.data',
    embedding_function=embeddings
)
 
    # 임베딩 요청을 배치로 처리
batch_size = 10  # 원하는 배치 크기
for i in range(0, len(splitted_documents), batch_size):
    batch_documents = splitted_documents[i:i+batch_size]
    database.add_documents(batch_documents)


database.add_documents(splitted_documents)

print('데이터베이스 생성이 완료되었습니다.')
