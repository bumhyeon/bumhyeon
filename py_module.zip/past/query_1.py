from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import Chroma

# OpenAI 임베딩 설정
embeddings = OpenAIEmbeddings(
    model="text-embedding-ada-002",
    openai_api_key="sk-proj-PKrHrTkG6coWLfyNKXglT3BlbkFJrGLttSNNW8kiqL8ZUqsS"
)


# Chroma 데이터베이스 생성 및 문서 추가
database = Chroma(
    persist_directory='./.data',
    embedding_function=embeddings
)

documents = database.similarity_search('비행 자동차의 최고 속도는?')

print(f"문서 개수: {len(documents)}")

for document in documents:
    print(f'문서 내용: {document.page_content}')
