import os
import chainlit as cl
from langchain_openai import OpenAIEmbeddings, ChatOpenAI
from langchain.document_loaders import PyMuPDFLoader
from langchain.prompts import PromptTemplate
from langchain.schema import HumanMessage
from langchain.text_splitter import SpacyTextSplitter
from langchain_community.vectorstores import Chroma

# OpenAI 임베딩 설정
api_key = "sk-proj-PKrHrTkG6coWLfyNKXglT3BlbkFJrGLttSNNW8kiqL8ZUqsS"
embeddings = OpenAIEmbeddings(
    model="text-embedding-ada-002",
    openai_api_key=api_key
)

chat = ChatOpenAI(
    model="gpt-3.5-turbo",
    openai_api_key=api_key
)

prompt = PromptTemplate(template="""문장을 바탕으로 질문에 답하세요.
    
문장: 
{document}

질문: {query}
""", input_variables=['document', 'query'])

text_splitter = SpacyTextSplitter(chunk_size=300, pipeline="ko_core_news_sm")

@cl.on_chat_start
async def on_chat_start():
    await cl.Message(content="PDF 파일을 업로드해 주세요.").send()

@cl.on_file_upload
async def on_file_upload(file):
    if not os.path.exists('tmp'):
        os.mkdir('tmp')

    file_path = f"tmp/{file.name}"
    with open(file_path, "wb") as f:
        f.write(file.content)

    documents = PyMuPDFLoader(file_path).load()
    splitted_documents = text_splitter.split_documents(documents)

    database = Chroma(
        persist_directory='./.data',
        embedding_function=embeddings,
    )

    database.add_documents(splitted_documents)

    cl.user_session.set("database", database)

    await cl.Message(content=f"'{file.name}' 로딩이 완료되었습니다. 질문을 입력하세요").send()

@cl.on_message
async def on_message(input_message):
    print('입력된 메시지: ' + input_message)

    database = cl.user_session.get('database')

    documents = database.similarity_search(input_message)

    documents_string = ""

    for document in documents:
        documents_string += f"""
    ------------------------
    {document.page_content}
    """

    result = await chat.agenerate([
        HumanMessage(content=prompt.format(document=documents_string, 
                                           query=input_message))
    ])

    choices = result.choices
    if choices:
        await cl.Message(content=choices[0].message.content).send()
    else:
        await cl.Message(content="응답이 없습니다.").send()
