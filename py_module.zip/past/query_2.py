from langchain.vectorstores import Chroma 
from langchain.embeddings import OpenAIEmbeddings
import os
from langchain_openai import ChatOpenAI
from langchain.schema import HumanMessage
from langchain.prompts import PromptTemplate

# OpenAI 임베딩 설정
embeddings = OpenAIEmbeddings(
    model="text-embedding-ada-002",
    openai_api_key="sk-proj-PKrHrTkG6coWLfyNKXglT3BlbkFJrGLttSNNW8kiqL8ZUqsS"
)

# Chroma 데이터베이스 생성 및 문서 추가
database = Chroma(
    persist_directory='./.data',
    embedding_function=embeddings
)

query = '비행 자동차의 최고 속도는?'

documents = database.similarity_search(query)

documents_string = ""

for document in documents:
    documents_string += f"""
------------------------
{document.page_content}
"""

prompt = PromptTemplate(
    template="""문장을 바탕으로 질문에 답하세요
    
문장: 
{document}

질문: {query}
""",
    input_variables=['document', 'query']
)

chat = ChatOpenAI(
    model="gpt-3.5-turbo",
    openai_api_key="sk-proj-PKrHrTkG6coWLfyNKXglT3BlbkFJrGLttSNNW8kiqL8ZUqsS"
)

result = chat([
    HumanMessage(content=prompt.format(document=documents_string, query=query))
])

print(result.content)
